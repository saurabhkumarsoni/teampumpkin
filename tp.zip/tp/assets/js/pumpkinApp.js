var app = angular.module('TeamPumpkinApp', ['ngRoute', 'ui.bootstrap', 'ngAnimate', 'ngSanitize', 'oitozero.ngSweetAlert']);

app.config(['$locationProvider', function ($locationProvider) {
    $locationProvider.hashPrefix('');
}]);

app.config(['$routeProvider', '$qProvider', function ($routeProvider) {

    $routeProvider
        .when('/', {
            templateUrl: 'assets/pages/login.html',
            controller: LoginCtrl
        })
        .when('/login', {
            templateUrl: 'assets/pages/login.html',
            controller: LoginCtrl
        })
        .when('/Signup', {
            templateUrl: 'assets/pages/Signup.html',
            controller: LoginCtrl
        })
        .when('/forgotpassword', {
            templateUrl: 'assets/pages/ForgotPwd.html',
            controller: LoginCtrl
        })
        .when('/Dashboard', {
            templateUrl: 'assets/pages/dashboard.html',
            controller: DashController
        })
        .when('/Clients', {
            templateUrl: 'assets/pages/clients.html',
            controller: ClientsCtrl
        })
        .when('/Profile', {
            templateUrl: 'assets/pages/profile.html',
            controller: ProfileCtrl
        })
        .when('/AboutUs', {
            templateUrl: 'assets/pages/aboutus.html',
            controller: AboutUsCtrl
        })
        .when('/Contact', {
            templateUrl: 'assets/pages/contact.html',
            controller: ClientsCtrl
        })
        .when('/Coverage', {
            templateUrl: 'assets/pages/coverage.html',
            controller: ClientsCtrl
        })
}]);
app.controller("Navbarcontroller", function ($scope) {

    setTimeout(function () {
        $scope.$apply(function () {
            /* ----toggle Navbar QuickLinks----- */
            $('#Q-link').on('click', function () {
                $('.QL-wrap, #Q-link').toggleClass('active');
            });
            /* ----toggle Navbar dropdown----- */
            $('#dd').click(function () {
                $(this).toggleClass('active');
            });
        });
    }, 800);

});
app.controller("headerBarCtrl", function ($scope) {



});


