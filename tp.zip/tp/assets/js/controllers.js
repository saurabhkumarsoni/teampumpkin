/*---------------------------------------Login Controller -----------------------*/
function LoginCtrl($scope, $location) {
	console.log("Inside login controll ");

	$('body').removeClass('modal-open');
	$('.modal-backdrop').remove();
	$('.carousel').carousel({
		interval: 3000
	});

	$('.toggle').on('click', function () {
		$('.contnr').stop().addClass('active');
	});

	$('.close').on('click', function () {
		$('.contnr').stop().removeClass('active');
	});
	$scope.items = [];
	$scope.selectedItem = { name: 'Gender', id: 0 };
	$scope.items = [{ name: 'Gender', id: 0 }, { name: 'Male', id: 1 }, { name: 'Female', id: 2 }, { name: 'Others', id: 3 }];

	$scope.login = function () {
		debugger;
		$location.path("/Dashboard");
	}


}
/*---------------------------------------Dashboard Controller -----------------------*/
function DashController($http, $scope, $location) {
	debugger;
	console.log("welcome to dashboard Controller");
	//am chart start
	am4core.useTheme(am4themes_animated);
	var chart = am4core.create("chartdiv", am4charts.PieChart);
	// Add data
	chart.data = [{
		"country": "Lithuania",
		"litres": 501.9
	}, {
		"country": "Czech Republic",
		"litres": 301.9
	}, {
		"country": "Ireland",
		"litres": 201.1
	}, {
		"country": "Germany",
		"litres": 165.8
	}, {
		"country": "Australia",
		"litres": 139.9
	}, {
		"country": "Austria",
		"litres": 128.3
	}, {
		"country": "UK",
		"litres": 99
	}, {
		"country": "Belgium",
		"litres": 60
	}, {
		"country": "The Netherlands",
		"litres": 50
	}];

	// Add and configure Series
	var pieSeries = chart.series.push(new am4charts.PieSeries());
	pieSeries.dataFields.value = "litres";
	pieSeries.dataFields.category = "country";
	pieSeries.innerRadius = am4core.percent(50);
	pieSeries.ticks.template.disabled = true;
	pieSeries.labels.template.disabled = true;

	let rgm = new am4core.RadialGradientModifier();
	rgm.brightnesses.push(-0.8, -0.8, -0.5, 0, - 0.5);
	pieSeries.slices.template.fillModifier = rgm;
	pieSeries.slices.template.strokeModifier = rgm;
	pieSeries.slices.template.strokeOpacity = 0.4;
	pieSeries.slices.template.strokeWidth = 0;


}
/*---------------------------------------clients Controller -----------------------*/
function ClientsCtrl($http, $scope, $location, SweetAlert) {
	console.log("welcome to ClientsCtrl");
	$scope.myVar = true;
	$scope.toggle = function () {
		$scope.myVar = !$scope.myVar;
	};
	$scope.isNavCollapsed = false;
	$scope.today = function () {
		$scope.hpl_HospitalDate = new Date();
		$scope.hpl_DishchargeDate = new Date();
		$scope.hpl_NextVisitDate = new Date();
	};
	$scope.today();
	$scope.clear = function () {
		$scope.hpl_HospitalDate = null;
		$scope.hpl_DishchargeDate = null;;
		$scope.hpl_NextVisitDate = null;
	};
	$scope.inlineOptions = {
		minDate: new Date(),
		showWeeks: true
	};
	$scope.dateOptions = {
		formatYear: 'yy',
		maxDate: new Date(2025, 5, 22),
		minDate: new Date(),
		startingDay: 1
	};
	$scope.dateOptions1 = {
		formatYear: 'yy',
		maxDate: new Date(),
		minDate: new Date(1980, 5, 22),
		startingDay: 1
	};
	$scope.ismeridian = true;
	$scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
	$scope.format = $scope.formats[0];
	$scope.altInputFormats = ['M!/d!/yyyy'];
	$scope.open1 = function () {
		$scope.popup1.opene1 = true;

	};
	$scope.open2 = function () {
		$scope.popup2.opene2 = true;
	};
	$scope.open3 = function () {
		$scope.popup3.opene3 = true;
	};
	$scope.setDate = function (year, month, day) {
		$scope.hpl_HospitalDate = new Date(year, month, day);
		$scope.hpl_DishchargeDate = new Date(year, month, day);
		$scope.hpl_NextVisitDate = new Date(year, month, day);
	};
	$scope.popup1 = {
		opene1: false
	};
	$scope.popup2 = {
		opene2: false
	};
	$scope.popup3 = {
		opene3: false
	};
	$scope.editRecord = function (recId) {
		$scope.myVar = !$scope.myVar
	}
	$scope.deleteReord = function () {
		debugger;
		SweetAlert.swal({
			title: "Are you sure?",
			text: "Your will not be able to recover this imaginary file!",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55", confirmButtonText: "Yes, delete it!",
			cancelButtonText: "No, cancel plx!",
			closeOnConfirm: false,
			closeOnCancel: false
		},
			function (isConfirm) {
				if (isConfirm) {
					SweetAlert.swal("Deleted!", "Your imaginary file has been deleted.", "success");
				} else {
					SweetAlert.swal("Cancelled", "Your imaginary file is safe :)", "error");
				}
			});
	}
}

/*---------------------------------------Dashboard Controller -----------------------*/
function ProfileCtrl($http, $scope, $location) {
	console.log("welcome to Solutions Controller");
}

function AboutUsCtrl($http, $scope, $location) {
	console.log("welcome to AboutUs Controller");
}



function ContactUsCtrl($http, $scope, $location) {
	console.log("welcome to ContactUsCtrl Controller");
}

