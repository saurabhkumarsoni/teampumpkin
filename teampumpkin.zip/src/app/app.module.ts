import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

import { AppComponent } from './app.component';
import { MentorComponent } from './mentor/mentor.component';
import { TutorsComponent } from './tutors/tutors.component';
import { ContentComponent } from './content/content.component';

import { ResourceComponent } from './resource/resource.component';
import { FooterComponent } from './footer/footer.component';
import { StudentComponent } from './student/student.component';
import { HeaderComponent } from './header/header.component';
import { SocialComponent } from './social/social.component';
import { NavigationComponent } from './navigation/navigation.component';
import { AppRoutingModule } from './/app-routing.module';
import { BannerComponent } from './banner/banner.component';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    MentorComponent,
    TutorsComponent,
    ContentComponent,
  
    ResourceComponent,
    FooterComponent,
    StudentComponent,
    HeaderComponent,
    SocialComponent,
    NavigationComponent,
    BannerComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AngularFontAwesomeModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
