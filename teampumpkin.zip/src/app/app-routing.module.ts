import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MentorComponent } from './mentor/mentor.component';
import { TutorsComponent } from './tutors/tutors.component';
import { ContentComponent } from './content/content.component';
import { ResourceComponent } from './resource/resource.component';
import { StudentComponent } from './student/student.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
const routes: Routes = [
  { path: '', redirectTo: '/Home', pathMatch: 'full' },
  { path: 'Home', component: HeaderComponent },
  { path: 'Mentor', component: MentorComponent },
  { path: 'Tutors', component: TutorsComponent },
  { path: 'About', component: ContentComponent },
  { path: 'Resources', component: ResourceComponent },
  { path: 'Student', component: StudentComponent },
  { path: 'login', component: LoginComponent },
  
  
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [ RouterModule ],
  declarations: []
})
export class AppRoutingModule { }
